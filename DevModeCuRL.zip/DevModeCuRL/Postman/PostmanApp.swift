    //
    //  PostmanApp.swift
    //  devmodecurl
    //
    //

import SwiftUI

@main
struct PostmanApp: App {
    var body: some Scene {
        WindowGroup {
            RequestView()
        }
    }
}
